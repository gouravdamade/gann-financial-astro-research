"""Record new working-tree identity and actual receipt; run both modes in separate processes."""
from pathlib import Path
from datetime import datetime,timezone
import sys,os,tempfile,json,hashlib
root=Path('D:/gann_r2b_sec_integration')
files=['financial_astro_ephemeris.py','gann-astro-desk/backend/avg_all_currency_phase.py','swiss_ephemeris_runtime.py','test_swiss_ephemeris_runtime_r7b.py','gann-astro-desk/backend/test_avg_all_currency_phase.py']
def digests():return {f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}
before=digests()
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'gann-astro-desk/backend'))
import avg_all_currency_phase as m
import financial_astro_ephemeris as e
import pandas as pd
with tempfile.TemporaryDirectory() as tmp:
    fallback='--fallback' in sys.argv
    os.environ['GANN_ASTRO_EPHEMERIS_PATH']=tmp if fallback else 'D:/Trading_Algo/Desktop_Trading_Algo_root_legacy_20260530/sweph'
    t=int(datetime(2025,5,31,17,tzinfo=timezone.utc).timestamp())
    a=m.build_avg_all_currency_phase(dict(symbol='USDJPY',timeframe='H1',timestamps=[t]))
    b=m.build_avg_all_currency_phase(dict(symbol='USDJPY',timeframe='H4',timestamps=[t]))
    try:
        strict=e.fetch_planetary_longitude('SUN',pd.to_datetime([t],unit='s',utc=True),'sidereal','geo',provider_policy='STRICT_SWISS_FILE')
        strict_result={'value':float(strict.iloc[0])}
    except Exception as ex:strict_result={'error':str(ex)}
    q=a.get('ephemerisProvenance',{})
    groups=[q.get('transitByBody',{}),*q.get('natalByCurrencyAndBody',{}).values()]
    rows=[s for g in groups for v in g.values() for s in (v or [])]
    result=dict(utc=datetime.now(timezone.utc).isoformat(),before=before,after=digests(),stable=before==digests(),mode='fallback' if fallback else 'swiss',contract=a['astronomyContract'],provenance=q,receipt_count=len(rows),providers=sorted(set(r['actualProvider'] for r in rows)),returned_flags=sorted(set(r['returnedFlags'] for r in rows)),file_ids_with_hash=sum(bool((r.get('ephemerisFileIdentity') or {}).get('sha256')) for r in rows),strict_low_level=strict_result,sample=a['phaseSamples'][0],same_h1_h4=a['phaseSamples']==b['phaseSamples'])
    print(json.dumps(result,indent=2))

