# 11 — Product and UX audit

The saved R6D Windows screenshot `native_screenshots/06-phase-diagnostics.png` shows Fields, USDJPY H1, three projection traces, R1/R2, a crosshair, selected values, a synthetic fixture label and a 14-day page control. Short traces occupy a small fraction of their fixed amplitude ranges. For the declared references the difference is mathematically bounded by ±0.844 while the screenshot uses ±2. Keeping global scale permits honest cross-window comparison, but flat-looking traces are an expected consequence. A labelled local scale with visible axis ticks can answer a different question. R7 records connected lines and scale modes; its native screenshot set was not saved.

A user examining a move should be able to select an exact UTC and see the candle source, whether that timestamp was a candle open or independently generated, actual provider, all ten member longitudes, status, projection values and comparison range. Separate a continuous astronomy timeline (7, 30, 90, 365 days) from chart-candle sampling. Weekends can be valid in astronomy and absent from the market series. A chart gap, missing ephemeris, numerical zero and undefined circular heading each need distinct render states. The Heuristic R1 cutoffs are 10⁻⁸, 0.20 and 0.65, with R2 0.55 for bipolar classification. Show what threshold was applied. A tooltip must label nearest versus exact UTC and distance to the selected sample. Wrapped 359°→1° requires a split or explicit unwrap.

The current service accepts at most 1,200 timestamps. A 365-day H1 timeline needs 8,760 or 8,784 samples, before rendering any indicators. Paging an existing candle fixture cannot supply that requirement. Align both views on a shared calculation identity, page server samples, aggregate only for drawing, retain selected full-resolution values and benchmark cold/warm latency on the target laptop. The historical R6D note reported 13.6–30 s on some requests before the present cache change. That figure is a historical observation, not a fresh timing benchmark. No current native process was observed on the process check. Launching a released binary with a different code identity would not verify the working R7B-R1 implementation. Native restart certification remains open.


**Read-only backend benchmark.** A single process requested increasing hourly batches on this laptop. Times below cover function execution. Compact JSON bytes describe the entire response, including collective diagnostics. They exclude HTTP transport, native rendering and database access. They are observations from one run on a concurrently used machine. The exact code identity at the start of this benchmark was not hashed; provider conclusions rely on the separately pinned probes.

| Samples | Function time (s) | Compact JSON (MiB) | Valid samples |
|---:|---:|---:|---:|
| 1 | 2.006 | 0.03 | 1 |
| 168 | 65.107 | 1.70 | 168 |
| 336 | 127.674 | 3.38 | 336 |
| 720 | 270.536 | 7.21 | 720 |
| 1200 | 460.074 | 12.01 | 1200 |
| 336 | 218.684 | 3.38 | 336 |

The 1,201-sample request was rejected by the existing limit. This measures why payload size and page width matter when planning the independent timeline.

**Where the calculation time went.** The backend parsed the doctrine YAML 96 times for one timestamp and 236 times for eight. In an isolated twelve-timestamp run, the unmodified backend took 6.17 seconds. Reusing one already-loaded doctrine configuration in memory took 0.12 seconds and produced identical hashes for phase samples, natal references, per-body provenance and collective diagnostics. The baseline ran first on one machine. This isolates a candidate cause of latency. A controlled cold/warm benchmark is still needed to estimate the gain for a release.

