# 19 — Bounded implementation directives

These tasks are proposals for separate authorized work. Their priorities, dependencies and proposed owners are given in report 17.

**A. Terra High — R7B-R1 end-to-end provenance.** Coordinate with the existing feature-tree owner. Freeze the exact source identity. Follow one timestamp through batch, single, SBC and the phase API. Verify and reuse the new 24 per-body receipts for a one-sample request. Trace their consumption through the native inspector and export. Preserve strict rejection and labelled permissive success against the same empty directory. Reopen the native process twice and compare selected UTCs. Deliver the implementation diff, reproducible fixture, capture and artifact impact list.

**B. Luna Max — circular degeneracy.** Use ten longitudes spaced 36° apart and repeat after a common 0.001° rotation. Establish first- and second-moment validity separately. Exercise the API and tooltip with an axial bipolar sample and a genuinely missing body. Retain valid zero projections. Deliver a test showing that an undefined direction can never appear as a precise scientific angle.

**C. Terra High — source errata.** Compare the previously corrected nightly source contract at a32c3a3 with the active product worktree. Start at the 1972 original printed p. 19 v. 77 and its neighboring page. Record source SHA, zero-based index, one-based PDF page, printed leaf, literal, unit uncertainty and consumer search. Compare the 2016 reprint separately. Do the same for Raman pp. 13 and 24 and the 1935 Manual p. 102. Deliver a versioned errata proposal and an independent second transcription before changing any operator.

**D. Luna Max — long-range and chart inspection.** After the shared sample passes A and B, implement independent UTC-grid and chart-candle samplers. Use identical raw calculations at intersecting timestamps. Verify missing samples, weekends, predeclared sampling limits, wrap and crosshair selection. Capture the native application with source labels and latency measurements at four horizons. Deliver two inspector workflows, each with a reproducible sample.

**E. Luna Max — statistical erratum.** Use the frozen M0 prediction vector from 2022 validation/test. Verify that its peak-to-peak range is zero, correlation is undefined, and the published 2022 validation CSV contains a tiny finite number. Produce a separate erratum plus a constant-series fixture. Retain the frozen original and every primary forecast/error statistic.

**F. Astra 6.2 — scope-adjudicated history.** Reconcile the 1,102- and 237-record inventory schemas by proposition, citation, worktree and use. Match historical claims to supplied images, code or test results, with each unresolved doctrine group explicitly assigned. Record original attachments or conversations that are still inaccessible. Deliver a reviewed crosswalk with no inferred source closure from a passing test.

