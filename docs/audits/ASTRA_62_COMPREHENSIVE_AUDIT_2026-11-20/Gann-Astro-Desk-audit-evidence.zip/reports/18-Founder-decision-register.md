# 18 — Founder decision register

1. **Currency identity.** Retain the July 1776 Philadelphia noon and February 1889 Tokyo midnight charts as explicitly named research scenarios, or fund historical source work to define another scenario. The original artifacts must retain their two timestamps whichever option is chosen.
2. **Research interface.** Choose which view should open first after provenance is fixed: candle-synchronized chart inspection or the independent long-range astronomy timeline. Both can share one sample contract. This choice governs user experience and acceptance order.
3. **Legacy comparison.** Decide whether uncertain R6/R7 values need a visible historical comparison mode or only an archival record. File identity, corrected calculation and honest fallback labelling are engineering requirements either way.
4. **Optional research after closure.** Choose whether the next independent study is a classical source reconstruction, an original Gann chart, or a preregistered empirical experiment. Current numerical results do not supply a reason to start a new fitted model.

