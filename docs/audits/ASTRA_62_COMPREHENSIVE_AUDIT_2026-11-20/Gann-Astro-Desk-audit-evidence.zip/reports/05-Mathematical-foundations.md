# 05 — Mathematical foundations

Let T = mean(exp(iθₖ)) over the transit bodies and N = mean(exp(iφⱼ)) over the natal bodies. Define P as the mean of cos(θₖ − φⱼ) over all ordered transit/natal pairs. Expanding exp(iθₖ)exp(−iφⱼ) and taking the real part gives **P = Re(T conjugate(N)) = TₓNₓ + TᵧNᵧ**. This proves the identity for 49 and 70 terms without using application code. Both means divide by their membership count. Normalizing T or N to length one would silently remove coherence and change the signal.

For fixed natal vectors U and J, **D = Pᵤ − Pⱼ = T · (U − J)**. Consequently |D| ≤ |T| |U − J| ≤ |U − J| ≤ 2. The actual bound for the declared references is **0.8439451117**. Positive means the transit mean projects more strongly onto the USD reference. Zero occurs at T = 0 or when T is perpendicular to the reference difference. Swapping pair order reverses the sign. Common rotation of all three vectors leaves P and D invariant. An epoch-dependent rotation or change applied to transit alone need not cancel.

| Declared reference | Real component | Imaginary component |
|---|---:|---:|
| USD | 0.08260909 | 0.58014529 |
| JPY | 0.39263895 | −0.20479091 |

Their determinant is −0.24470523. Given both projections and these two known axes, a 2×2 linear solve reconstructs T. Given D alone, the component perpendicular to U−J is lost. Even perfect knowledge of T cannot identify the planets behind it. As a counterexample, five bodies at 0° plus five at 180° and five evenly spaced antipodal pairs can both have T = 0. The former has |mean(exp(2iθ))| = 1, while a regular decagon has 0. Thus R2 contains genuine complementary information. Circular variance 1−R1 is a re-expression of R1. A valid zero vector has a defined zero projection and an undefined heading. A missing body invalidates the specified population.

The oracle checked 1,024 seeded skies and both member counts, including rotation, permutation and known antipodal examples. Worst direct/factorized difference was 1.95 × 10⁻¹⁶ or less. At 2025-05-31 17:00 UTC the direct 70-term result was USD 0.2213210042, JPY 0.1247132838, difference 0.0966077204. The Swiss-file working service agreed within floating-point rounding. A +1 h shift to the USD or JPY natal time changes its mean vector by 0.001358 or 0.001239 respectively. These are upper bounds on the corresponding projection changes for any transit vector, a local sensitivity experiment with no market selection.

