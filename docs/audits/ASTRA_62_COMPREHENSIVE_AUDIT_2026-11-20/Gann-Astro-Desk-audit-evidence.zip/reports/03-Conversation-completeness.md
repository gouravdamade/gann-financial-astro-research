# 03 — Conversation completeness

| File | Capture or dated record | Extent | Recoverable structure and loss |
|---|---|---:|---|
| Gann Astro Repo Watch.pdf | Created 7 Aug UTC, printed 8 Aug local | 221 pp. | Browser print, 17 image occurrences. Reliable message count unavailable. |
| 190826.docx | Opens 7 Aug, includes subsequent August discussion | 7,447 XML paragraphs | One media part, 353 blank paragraphs. Eight recognizable weekday/time headings span 7–10 August; other text is not separately dated. No stable per-message role IDs. |
| MO-R4A Overnight Research.pdf | Created 10 Sep | 798 pp. | 73 image occurrences. 31 recognizable weekday/time headings include 20–31 August. Page 1 has fragmented text order and the final page contains a delivery timeout. |
| Repository Familiarization.pdf | Created 17 Sep | 1,038 pp. | 22 image occurrences. Closing discussion itself questions the export page count. |
| conversation.pdf | 23 Sep | 917 pp. | Project Update Summary. All 152 numbered turns recoverable, 3 image warnings. |
| conversation2.pdf | 3 Oct | 625 pp. | Nightly Project Research. All 108 numbered turns, 20 image warnings. |
| conversation3.pdf | 8 Oct | 116 pp. | Repository Familiarization Summary. All 60 numbered turns, 9 image warnings. Final turn is a short status fragment. |
| conversation4.pdf | 11 Nov | 120 pp. | Same title as the previous file, 61 numbered turns, 9 image warnings. Treat as overlapping history. |
| conversation5.pdf | 19 Nov | 801 pp. | Export title “3. My architectural decision”. All 281 numbered turns, 21 image warnings. Upload placeholders include historical source materials. |

There are 662 numbered turns across the five captures **before deduplication**. All eight PDFs contained recoverable text on every page. None of the nine containers exposed embedded attachment files in the tested PDF/OOXML embedding inventories. Some images in browser prints survived, while the five numbered archives had no enumerated PDF raster images. Formula layout, superscripts, image-only evidence and code indentation cannot be certified from extracted text. Source dates mentioned within turns include quoted historical events and research periods and are unsuitable as message dates. The five numbered archives contain 62 explicit image-preservation warnings in total. Each warning is an export event, not a count of distinct lost originals. The manifest retains the hashes, metadata and boundary text. Topic-index hits are locators and require reading their surrounding pages to determine authorship and disposition.

