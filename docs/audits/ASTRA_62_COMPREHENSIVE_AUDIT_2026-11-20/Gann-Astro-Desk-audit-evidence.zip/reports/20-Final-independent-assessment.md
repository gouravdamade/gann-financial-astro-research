# 20 — Final independent assessment

| Founder’s analytical question | Answer |
|---|---|
| 1. Is the Multi Oscillator mathematically coherent? | Yes for the declared normalized equal-cosine projections and their difference. Undefined angles and input provenance need separate treatment. |
| 2. Which components are independent? | Two non-collinear natal projections encode the two real components of T. The difference adds no dimension. R2 and labelled body positions can contribute additional information. |
| 3. Are important formulas incorrect? | Projection arithmetic passed. Near-zero headings are numerically meaningless, several printed totals are arithmetically wrong, and a literal in the motion configuration disagrees with its scan. |
| 4. Which calculations are redundant? | Rebuilding T twice per service sample, using 1−R1 as another vote and counting D alongside both legs. |
| 5. Which source claims are overstated? | Universal A-policy authority, exact natal history, fully certified Dṛk and the current Swiss-file label exceed their evidence. |
| 6. What classical calculations are missing? | Source-complete special Dṛk branches and intermediate precision, quantitative Ceṣṭā policies, simultaneous modifier rules and persistence. |
| 7. Are the frames appropriate? | Geocentric ecliptic longitude is suitable for the declared angular construction. Kolkata rise/set requires local coordinates. Historical clock and epoch conventions limit precision. |
| 8. Can every result be reproduced? | The frozen 03C-R1/03E series and predictions reproduced. The API label alone cannot guarantee the same native result or provider. |
| 9. Are natal assumptions defensible? | As declared scenario inputs, yes. The cited histories do not warrant exact currency inception times. |
| 10. Are USD/JPY projections meaningful astronomical constructs? | Yes as projections onto two chosen historical reference vectors. Their meaning depends on those choices and the body set. |
| 11. Is a financial advantage established? | No. All three prespecified paired intervals cross zero, and M4 loses to M0 in both replications. |
| 12. Which negative findings constrain claims? | Preserve the frozen Candidate C outcome and 03D/03E results for their recorded populations. Retrospective retuning would require a different claim and independent data. |
| 13. What proposals lack evaluation? | The full/new-Moon regime-and-recovery BTC study, Kolkata physical overlay and longer candle-independent chart comparison. |
| 14. Which warnings were insufficiently addressed? | September assumption records already called out discarded provider flags and civil UTC-as-UT. The closing backend now exposes realized identity. Native visibility and use by every consumer remain unverified. |
| 15. Do primary sources contradict implementation? | The 1972 Jupiter literal disagrees with the active source configuration. The printed Raman tables also contradict some common numerical expectations. |
| 16. Which texts are still needed? | Edition-matched Raman §§136–137 and errata, collated BPHS and Śrīpati, a second Trailokya reading and dated original Gann lesson/chart. See report 14. |
| 17. Most important unresolved mathematical issue? | Preserve valid magnitude/projection at cancellation while withholding undefined direction, and keep attribution to individual bodies available. |
| 18. Most important astronomical issue? | Bind each returned sample to its realized provider, frame, time convention and files through service and native restart. |
| 19. Most important source issue? | Determine where a printed same-chart numerical relationship ends and a modern mixed-epoch application begins. Fix the identified literal within that effort. |
| 20. Most important product issue? | Inspect a long-range trajectory and the same exact UTC inside the chart with truthful source, gaps and scale. |
| 21. Most important statistical weakness? | Overlapping historical targets and period/regime dependence leave small incremental gains uncertain. An untouched forward evaluation is absent. |
| 22. What should stop? | Treating display derivatives as independent confirmations, tuning on frozen negative periods and labelling experimental signs as market direction. |
| 23. What should be simplified? | Shared unrounded sample and Cartesian moments, one provider contract, distinct market and astronomy samplers. |
| 24. What should be independently reimplemented? | Full caller-to-file provenance and per-aspector Dṛk traces next. Independent projection, seven-body feature and market oracles are supplied. |
| 25. What should be researched next? | Effective ephemeris provenance first; source glyph, printed precision and per-aspector reconciliation can proceed independently. |
| 26. What should stay frozen? | EMP2-R2, 03C/03D/03E data, coefficients, bootstrap indices, source originals and historical UI evidence. |
| 27. Which conclusions should be withdrawn? | Label-only Swiss certification; generalization from 49 scores to all Śaḍbala; exact market inception from registry IDs; a third independent vote from D. |
| 28. What is ready for inspection? | Source page anomalies, numerical outputs, recorded Fields screenshot and the verified working service sample. Current full native acceptance is outstanding. |
| 29. Minimum reproducible instrument? | An exact timestamp, pinned references/body set, realized ephemeris receipt, raw inputs, projection and validity state, plus a restart-verifiable inspector. |
| 30. Most defensible long-term architecture? | A reproducible astronomical sample layer with separately versioned classical operators, experimental geometry and frozen empirical models, consumed by chart and timeline views. |

The coverage index records 55 examined items and 39 with partial coverage. The audit materials contain a 94-item brief coverage index, inventories for the 1,102- and 237-record historical ledgers, 662 numbered-turn locators, and the independent scripts and results. Source excerpts in the indexes are pointers for further review.

**Coverage limits.** This audit includes direct primary-page inspection at named loci, service execution, independent external astronomy, complete hourly reconstruction of the specified features, frozen-market replication and bounded source/history reviews. It does not establish every historical turn or attachment, every BPHS recension, every active caller and timestamp conversion, every compiled binary’s behavior, every original Gann chart, or every proposition’s historical truth. The partial designation preserves those boundaries.

