# 12 — Contradictions and superseded decisions

| Earlier or competing claim | Evidence on the other side | Disposition |
|---|---|---|
| A Raman/Swiss label identifies the calculation | Identical response contract, different provider flags and D in the two service probes | Withdraw provider certainty based on label alone. P0. |
| Every historical geometric feature needs regeneration | Independent reconstruction of all 03C-R1/03E hourly feature rows | Preserve those exact frozen artifacts. Re-evaluate uncaptured R6/R7 epochs separately. |
| Seven-body outcomes validate the ten-body visual | Transit membership and design matrices differ | Remove any transfer of predictive status. |
| Three displayed traces are three agreeing votes | Third is exactly USD minus JPY; first two span T | Keep three useful views and one underlying geometric observation. |
| All 49 cells match, so every printed total is correct | Three row sums disagree with the printed totals | Store diplomatic transcription and computed total separately. |
| D30 is fully specified by its ruler | Two co-ruled sign choices change B’s score count | Scope A to declared natal policy and retain D30 sign uncertainty. |
| Jupiter’s literal is 14\|14 with direct agreement | Printed 1972 p. 19 v. 77 reads 14\|4; config and Word record agree with each other | Flag literal and scan-index provenance. Preserve historical versions. Unit still unknown. |
| Completion of classical audit certifies doctrine | 237-record ledger contains 12 unresolved groups and zero unfinished *coverage* entries | Keep both fields and show the appropriate status in source-driven modes. |
| Frozen M0 has a tiny measured correlation in 2022 | All forecasts are identical within a split | Display undefined; retain archive and add a linked correction. |
| Founder inspection means release or acceptance | R6D screenshot and R7 architectural decision explicitly separate them | Maintain distinct milestones for code, service, native, founder and release. |
| Quality report lists four crossed opens | Five raw weekly timestamps and five canonical flags agree, with zero OHLC discrepancies | Link a data-quality erratum. No return target uses the crossed open. |
| A 45° line has an invariant market meaning | Native grid has configurable increments, rendering and units | Reproduce a declared price and time scale for each example. |
| A source operator’s printed numeric magnitude is a market effect | No bridge establishes this interpretation; independent market tests remain inconclusive | Keep operator units, event categories and economic claims separate. |


