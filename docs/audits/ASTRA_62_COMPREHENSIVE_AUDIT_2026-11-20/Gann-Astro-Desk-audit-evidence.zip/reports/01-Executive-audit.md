# 01 — Executive audit

**The Multi Oscillator is defensible as an instrument for inspecting astronomical geometry. The available experiments do not establish a USDJPY forecasting advantage.** The arithmetic, the astronomical inputs, the historical authority of a rule, and the behavior of the installed application each need their own verdict.

| Question | Independent result | Evidence grade |
|---|---|---|
| Can the earlier experimental series be reproduced? | All 26,304 hourly seven-body samples for 2022–24 reproduced. Maximum absolute residual across both transit coordinates, both currency projections and their difference was 6.67 × 10⁻¹⁶ or less. | INDEPENDENTLY_REPRODUCED |
| Can the current ten-body service identify its effective ephemeris? | Yes in the later working snapshot. Each single-UTC request returned 24 provider records. With Swiss files all 24 had file hashes. With an empty directory all 24 named Moshier. The unchanged top-level Swiss-labelled string is ambiguous by itself. Native presentation remains unverified. | CODE_VERIFIED and independently exercised backend |
| Is the astronomical data itself plausible? | At one UTC, apparent geocentric tropical longitudes of Sun, Moon and Mercury agreed with JPL Horizons within 0.081 arcseconds. A separate Swiss test identifies the wrong sidereal zero-point in the original discrepancy. | INDEPENDENTLY_REPRODUCED, limited frame and epoch |
| Do currency traces provide three independent observations? | The two currency projections are independent linear coordinates for the declared natal axes. The third trace is exactly their difference. All three depend only on two components of the transit mean. | INDEPENDENTLY_REPRODUCED |
| Did adding the resultant improve prediction? | All three primary paired 95% intervals include zero. The augmented model also lost to the constant training-mean baseline on RMSE in both replication years. | INDEPENDENTLY_REPRODUCED |
| Are classical calculations closed? | Reproduced Raman’s 49 component scores under one explicit policy. Three printed row totals disagree with their own cells. The Trailokya working configuration also differs from the original page on Jupiter. | PRIMARY_SOURCE_VERIFIED for the specified pages, INDEPENDENTLY_REPRODUCED for the arithmetic |
| Is the product ready? | The Fields debug screenshot and current service support inspecting the concept. The longer astronomy timeline, chart-native currency-phase pane and restarted native provider identity still lack corresponding acceptance evidence. | CODE_VERIFIED for service, historical screenshot inspected, native state unverified |

The most efficient next milestone is one exact sample whose raw longitudes, effective provider, natal references, displayed value and restart result can all be inspected together. The evidence package pins inputs, hashes and reproduction scripts. No source change, release, merge, push or new market fitting experiment was part of this audit.

