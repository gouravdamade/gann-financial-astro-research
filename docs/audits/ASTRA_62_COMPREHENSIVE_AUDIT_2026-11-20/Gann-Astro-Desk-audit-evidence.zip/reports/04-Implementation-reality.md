# 04 — Implementation reality

| Surface | Where inspected | Status and boundary |
|---|---|---|
| Published workspace | GitHub master `35f6319aa0a984756c5b59bbd88c6ac8a0b5c7ea`, 2,896 tracked paths | Inventory covers chart app, research labs, configs, tests, evidence, legacy scripts, market records and annotation stores. |
| Historical checkouts | 46 remote branch heads, 127 local head/remote ref entries, 106 registered worktrees, 681 reachable commits in the captured log | Counts describe the local Git registrations. They do not establish 106 active applications. Branch map is in the evidence bundle. |
| Main D: checkout | `D:/PycharmProjects`, `544bf2c` | August SBC/Trailokya line. The historical C: checkout path did not exist in this session. |
| Current feature tree | `D:/gann_r2b_sec_integration`, `feature/mo-product-01-avg-all`, `e1b2f6350932165cdac8022314c78ebccad1a211` plus 107 short-status entries | Currency-phase module and runtime helper present as working files. A clone at the quoted SHA alone cannot reproduce this state. See file hashes and working changes. |
| R2C sibling | `D:/r2c`, same base SHA, different branch and dirty files | Its chart-native delivery branch name is insufficient evidence of the requested currency-phase pane. |
| Evaluators and EMP | A/B freeze, comparator, RUN1, EMP0/1/2 branches; `865e99e` final scientific closure | Separate research lineage. The historical reports attest to evaluation and closure. The entire private EMP outcome bridge was not replayed here. |
| Chart activity and Fields | F3/F4/F5 branch family, URW, frontend Fields views and R6D screenshot | Unsigned activity and the newer signed geometric difference are distinct. A working activity pane does not deliver a chart-native currency-phase pane. |
| Currency phase backend | `backend/avg_all_currency_phase.py`, actual H1/H4 service calls, native-independent oracle | Implementation and service verified at a shared UTC. No release promotion established. |
| R7B-R1 | `swiss_ephemeris_runtime.py`, batch engine, tests | 12 focused tests passed across two modules. The initial common API discarded provider. In the later snapshot 24 effective-provider records reached the real phase response, and the strict batch helper rejected fallback. |
| R7A timeline and new chart pane | R7A architecture and native evidence record | PROPOSED_NOT_IMPLEMENTED at that milestone. A current founder acceptance or packaged build with those features was not established. |

Evidence grades throughout retain their narrow meanings. A source page is evidence for its printed wording. A direct calculation is evidence for that calculation. A working Python service is insufficient evidence of a visible Windows application. Historical runtime claims are REPORTED_NOT_INDEPENDENTLY_VERIFIED unless identified as inspected screenshots.

