"""Read-only oracle. Run from any directory with pyswisseph and requests."""
from pathlib import Path
import sys, json, math, hashlib
from concurrent.futures import ThreadPoolExecutor
import requests
import swisseph as swe
root=Path(__file__).resolve().parent
files=Path(sys.argv[1]) if len(sys.argv)>1 else Path('D:/Trading_Algo/Desktop_Trading_Algo_root_legacy_20260530/sweph')
jd=swe.julday(2025,5,31,17)
# Match the application's UTC-as-UT contract in the historical reproduction.
flags=swe.FLG_SWIEPH|swe.FLG_SPEED
swe.set_ephe_path(str(files))
def sample(body,flags):
    values,ret=swe.calc_ut(jd,body,flags)
    return dict(lon=values[0],lat=values[1],flags=ret)
records={}
for mode in ('DEFAULT','FAGAN_BRADLEY','RAMAN','LAHIRI'):
    if mode!='DEFAULT':swe.set_sid_mode(getattr(swe,'SIDM_'+mode))
    records[mode]={name:sample(getattr(swe,name),flags|swe.FLG_SIDEREAL) for name in ['SUN','MOON','MERCURY']}
swe.set_sid_mode(swe.SIDM_RAMAN)
moshier=sample(swe.SUN,swe.FLG_MOSEPH|swe.FLG_SPEED|swe.FLG_SIDEREAL)
def ref(pair):
    name,obj=pair
    p=dict(format='json',COMMAND=str(obj),CENTER="'500@399'",MAKE_EPHEM="'YES'",EPHEM_TYPE="'OBSERVER'",START_TIME="'2025-05-31 17:00'",STOP_TIME="'2025-05-31 17:01'",STEP_SIZE="'1 m'",QUANTITIES="'31'",CSV_FORMAT="'YES'",ANG_FORMAT="'DEG'",EXTRA_PREC="'YES'",OBJ_DATA="'NO'")
    res=requests.get('https://ssd.jpl.nasa.gov/api/horizons.api',params=p,timeout=35)
    if not res.ok:
        p=dict(format='json',COMMAND=str(obj),CENTER='500@399',TLIST=str(jd),EPHEM_TYPE='OBSERVER',QUANTITIES='31',CSV_FORMAT='YES',EXTRA_PREC='YES',OBJ_DATA='NO')
        res=requests.get('https://ssd.jpl.nasa.gov/api/horizons.api',params=p,timeout=35)
    res.raise_for_status()
    body=res.json()['result']; (root/f'horizons-{name.lower()}.txt').write_text(body,encoding='utf8')
    row=body.split('$$SOE')[1].split('$$EOE')[0].strip().splitlines()[0].split(',')
    return name,dict(lon=float(row[3]),lat=float(row[4]),query=res.url)
tropical={name:sample(getattr(swe,name),flags) for name in ['SUN','MOON','MERCURY']}
with ThreadPoolExecutor(3) as pool:
    tasks=[pool.submit(ref,p) for p in [('SUN',10),('MOON',301),('MERCURY',199)]]
    horizons={}
    for t in tasks:
        try:
            name,r=t.result();horizons[name]=r
            r['swiss_minus_jpl_arcsec']=[3600*(tropical[name][k]-r[k]) for k in ['lon','lat']]
        except Exception as e: horizons[str(len(horizons))]=str(e)
digest=lambda f:hashlib.file_digest(f.open('rb'),'sha256').hexdigest()
result=dict(version=swe.version,binding=swe.__version__,jd=jd,requested=flags|swe.FLG_SIDEREAL,path=str(files),candidate_file_hashes={f.name:digest(f) for f in files.glob('*_18.se1')},mode=records,raman_moshier=moshier,tropical=tropical,horizons=horizons)
print(json.dumps(result,indent=2))

