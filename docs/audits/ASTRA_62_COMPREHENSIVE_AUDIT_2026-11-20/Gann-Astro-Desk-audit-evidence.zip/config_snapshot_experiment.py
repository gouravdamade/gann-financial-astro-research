"""Process-isolated counterfactual. No project files are edited or imported into a running application."""
from datetime import datetime,timezone
from pathlib import Path
from unittest.mock import patch
import sys,json,time,hashlib
sys.dont_write_bytecode=True
root=Path('D:/gann_r2b_sec_integration')
sys.path.insert(0,str(root/'gann-astro-desk/backend'))
import avg_all_currency_phase as m
import doctrine_config as conf
t=int(datetime(2025,5,31,17,tzinfo=timezone.utc).timestamp())
def run(n):
    start=time.perf_counter()
    a=m.build_avg_all_currency_phase(dict(symbol='USDJPY',timeframe='H1',timestamps=[t+i*3600 for i in range(n)]))
    elapsed=time.perf_counter()-start
    return a,elapsed
def fingerprint(a):
    subset={k:a[k] for k in ['phaseSamples','natalReferences','ephemerisProvenance','collectiveField']}
    return hashlib.sha256(json.dumps(subset,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
original,baseline=run(12)
frozen=conf.load_doctrine_config()
with patch.object(conf,'load_doctrine_config',lambda path=None:frozen):
    alternate,experimental=run(12)
assert fingerprint(original)==fingerprint(alternate)
print(json.dumps(dict(n=12,unmodified_seconds=baseline,isolated_fixed_config_seconds=experimental,equal_phase_natal_provenance_collective_hash=fingerprint(original),note='One process. Baseline first, then counterfactual. No cold/warm randomization or production optimization claimed.'),indent=2))

