"""Read-only secondary integrity checks, reference catalogs and edge fixtures."""
from pathlib import Path
import hashlib,sys,json,csv,collections,statistics
import numpy as np
repo=Path('D:/gann_r2b_sec_integration'); research=Path('D:/GannFinancialAstro/research_outputs')
out=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(repo/'gann-astro-desk/backend'))
import collective_geometry as g
v=g.calculate_collective_field({b:np.array([i*36.,i*36.+.001]) for i,b in enumerate(g.AVG_ALL_MEMBERS)},[1,2])['samples']
regular=[{k:x[k] for k in ('meanLongitudeDeg','polarisationAxisDeg','longitudeReliable','coherenceR1','polarisationR2','state')} for x in v]
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
market=next(research.glob('MO-PRED-03C_e*/MO*SOURCE_MANIFEST.json'))
manifest=json.loads(market.read_text()); ok=0; bad=[]; counts=collections.Counter()
for f in manifest['weekFiles']:
    counts[f['status']]+=1
    if f.get('sha256'):
        p=market.parent/'raw/fxcm/H1/USDJPY'/f['name']
        if p.exists() and digest(p).upper()==f['sha256'].upper():ok+=1
        else:bad.append(f['name'])
p=next((repo/'status/evidence').rglob('jhora_drik_independent_validation_values_20260726.csv'))
rows=list(csv.DictReader(p.open(encoding='utf-8-sig')))
res=[abs(float(r['local_value'])-float(r['external_expected_value'])) for r in rows]
ledger=repo/'status/audits/mo_r4a_astra_a1_r2_master_assumption_ledger.json'
a=json.loads(ledger.read_text(encoding='utf-8-sig')); oldpath=Path('D:/GannFinancialAstro/audits/mo-r4a-astra-a1-20260917/master_assumption_ledger.json')
old=json.loads(oldpath.read_text(encoding='utf-8-sig'))
with (out/'historical-propositions.tsv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.writer(f,delimiter='\t'); writer.writerow(['inventory','id','claim','historical_classification','historical_source_status','location','audit_treatment'])
    for family,entries in [('Sept-17',old['records']),('R2',a['records'])]:
        for e in entries:
            writer.writerow([family,e['assumptionId'],e.get('statement',''),e.get('classification') or e.get('primaryClassification',''),e.get('sourceStatus',''),json.dumps(e['repositoryLocations'][:1],ensure_ascii=False),'Inventory verified. Historical adjudication unless separately traced in report.'])
def hashfiles(paths):return {str(p):digest(p) for p in paths if p.is_file()}
inputs=[]
for patt in ['MO-PRED-03C_e*/MO*CANONICAL*.csv','MO-PRED-03C-R1*/*FEATURES.csv','MO-PRED-03E*/*FEATURES.csv','MO-PRED-03*/*PREDICTIONS.csv','MO-PRED-03*/*INDICES*.npy','SHADBALA_R1_5_R1*/*MATRIX.csv','SHADBALA_R1_3_*/raman_source.pdf','SHADBALA_R1_5_R1*/manual_1935.pdf','SHADBALA_R1_5_R1*/sripati_1937.pdf']:
    inputs.extend(research.glob(patt))
inputs+=[p,market,ledger,oldpath,Path('D:/GannFinancialAstro/sources/private/TRAILOKYA_DIPIKA_VYAS_1972_ORIGINAL_SCAN_1EF82899.pdf'),Path('D:/GannFinancialAstro/sources/classical/BPHS_1899_GOVIND_SHARMA_SHASTRI.pdf')]
result=dict(regularDecagon=regular,weekFileStatus=dict(counts),weeklyHashesVerified=ok,hashFailures=bad,drik=dict(n=len(res),withinHalf=sum(x<=.5 for x in res),mae=statistics.mean(res),max=max(res)),historicGroups=a['unresolvedDoctrineGroups'],inputHashes=hashfiles(inputs))
print(json.dumps(result,indent=2,ensure_ascii=True))

