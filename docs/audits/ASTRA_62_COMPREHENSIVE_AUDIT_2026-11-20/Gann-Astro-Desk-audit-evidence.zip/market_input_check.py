"""Verify every canonical quote against the corresponding preserved weekly source and regenerate bootstrap indices."""
from pathlib import Path
from collections import defaultdict
import gzip,csv,json
import numpy as np
r=Path('D:/GannFinancialAstro/research_outputs')
p=next(r.glob('MO-PRED-03C_e*/MO*CANONICAL*.csv'))
groups=defaultdict(list)
for row in csv.DictReader(p.open()):groups[row['rawFile']].append(row)
fields=[s+t for s in ('Ask','Bid') for t in ('Open','High','Low','Close')]
count=0;missing=0;differences=0;crossed=[]
for file,canon in groups.items():
    with gzip.open(p.parent/file,'rt',encoding='utf-8-sig') as f:
        source={row['DateTime']:row for row in csv.DictReader(f)}
    for row in canon:
        q=source.get(row['sourceTimestamp'])
        if q is None:missing+=1;continue
        differences+=sum(float(q[k])!=float(row[k]) for k in fields)
        if float(q['BidOpen'])>float(q['AskOpen']):crossed.append(row['candleStartUtc'])
        count+=1
res={}
for prefix,n in [('2022',935),('2023',3633),('2024',3456)]:
    f=next(r.glob('MO-PRED-03D-R1*/*INDICES.npy' if prefix=='2022' else f'MO-PRED-03E*/*INDICES_{prefix}.npy'))
    saved=np.load(f,mmap_mode='r');rng=np.random.default_rng(20261117);bad=0
    for original in saved:
        starts=rng.integers(0,n-168+1,size=(n+167)//168)
        expected=(starts[:,None]+np.arange(168)).ravel()[:n]
        bad+=int(not np.array_equal(original,expected))
    res[prefix]={'B':len(saved),'different_replicates':bad}
print(json.dumps(dict(verified_source_timestamps=count,missing_timestamps=missing,ohlc_field_disagreements=differences,crossed_open_rows=crossed,bootstrap=res),indent=2))

