"""Count configuration reads on a small actual phase request without changing the implementation."""
from pathlib import Path
from datetime import datetime,timezone
import sys,json,cProfile,pstats,hashlib,time
sys.dont_write_bytecode=True
root=Path('D:/gann_r2b_sec_integration')
sys.path.insert(0,str(root/'gann-astro-desk/backend'))
import avg_all_currency_phase as m
paths=[root/'financial_astro_ephemeris.py',root/'doctrine_config.py',Path(m.__file__)]
fingerprints={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
out={'source_sha256':fingerprints,'samples':[]}
t=int(datetime(2025,5,31,17,tzinfo=timezone.utc).timestamp())
for n in (1,8):
    profiler=cProfile.Profile();ts=[t+i*3600 for i in range(n)]
    start=time.perf_counter()
    a=profiler.runcall(m.build_avg_all_currency_phase,dict(symbol='USDJPY',timeframe='H1',timestamps=ts))
    stats=pstats.Stats(profiler).stats
    rows=[dict(file=k[0],function=k[2],calls=x[1],cumulative_seconds=x[3]) for k,x in stats.items() if k[2] in ('safe_load','load_doctrine_config','calc_ut')]
    out['samples'].append(dict(n=n,profiled_wall_seconds=time.perf_counter()-start,calls=rows,valid=sum(x['status']=='VALID' for x in a['phaseSamples'])))
print(json.dumps(out,indent=2))

