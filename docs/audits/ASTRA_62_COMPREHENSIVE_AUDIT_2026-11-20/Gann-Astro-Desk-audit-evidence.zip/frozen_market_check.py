"""Recalculate the existing research populations and forecasts without tuning."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
r=Path(sys.argv[1]) if len(sys.argv)>1 else Path('D:/GannFinancialAstro/research_outputs')
def one(pattern): return next(r.glob(pattern))
def table(pattern):return pd.read_csv(one(pattern),float_precision='round_trip')
c=one('MO-PRED-03C_e*/MO*CANONICAL*.csv')
bars=pd.read_csv(c,float_precision='round_trip')
bars.index=pd.to_datetime(bars.candleEndUtc,utc=True)
assert bars.index.is_unique
s=(bars.BidClose+bars.AskClose)/2
s=s.where((bars.BidClose>0)&(bars.AskClose>=bars.BidClose))
assert np.allclose(s,bars.midClose,equal_nan=True)
one_day=pd.Timedelta(days=1)
splits=json.loads(one('MO-PRED-03C-R1*/MO*EXPERIMENT_SPLITS.json').read_text())['splits']
spec=[(x['split'],pd.Timestamp(x['startUtc']),pd.Timestamp(x['endUtcExclusive']),x['eligibleOriginUtc']) for x in splits]
spec.extend((str(y),pd.Timestamp(f'{y}-01-01',tz='UTC'),pd.Timestamp(f'{y+1}-01-01',tz='UTC'),None) for y in (2023,2024))
coefs={}; features=[[],['lag'],['R'],['T_x','T_y'],['lag','R']]
answer={'sourceSha256':hashlib.file_digest(c.open('rb'),'sha256').hexdigest(),'populations':{}}
for label,start,end,expected in spec:
    y=start.year
    astro=table(('MO-PRED-03C-R1*/MO*2022' if y==2022 else f'MO-PRED-03E*/MO*{y}')+'_ASTRONOMICAL_FEATURES.csv')
    astro.index=pd.to_datetime(astro.timestampUtc,utc=True)
    ix=s.loc[(s.index>=start)&(s.index+one_day<end)].dropna().index.sort_values()
    ix=ix[s.reindex(ix-one_day).notna().to_numpy()&s.reindex(ix+one_day).notna().to_numpy()]
    if expected: assert set(ix)==set(pd.to_datetime(expected,utc=True))
    data=astro.loc[ix,['R','T_x','T_y']].copy()
    data['lag']=np.log(s.loc[ix].to_numpy()/s.loc[ix-one_day].to_numpy())
    target=np.log(s.loc[ix+one_day].to_numpy()/s.loc[ix].to_numpy())
    preds={};metrics={}; info={'n':len(ix),'first':str(ix[0]),'last':str(ix[-1])}
    for i,cols in enumerate(features):
        mat=np.column_stack([np.ones(len(ix))]+[data[k].to_numpy() for k in cols])
        if label=='train':coefs[i]=np.linalg.lstsq(mat,target,rcond=None)[0]
        p=mat@coefs[i];preds[i]=p;err=target-p; nz=target!=0
        metrics['M'+str(i)]={'mse':float(np.mean(err**2)),'rmse':float(np.sqrt(np.mean(err**2))),'mae':float(np.mean(abs(err))),'direction':float(np.mean(np.sign(p[nz])==np.sign(target[nz]))),'corr':float(np.corrcoef(p,target)[0,1]) if np.ptp(p)>0 else None}
    info['metrics']=metrics
    info['forecast_sign_counts']={f'M{i}':{'positive':int(np.sum(p>0)),'negative':int(np.sum(p<0)),'zero':int(np.sum(p==0))} for i,p in preds.items()}
    info['outcome_sign_counts']={'positive':int(np.sum(target>0)),'negative':int(np.sum(target<0)),'zero':int(np.sum(target==0))}
    if label!='train':
        if y==2022:
            disk=table('MO-PRED-03D-R1*/MO*PREDICTIONS.csv')
            disk=disk[disk.split==label].pivot(index='timestampUtc',columns='model',values='prediction')
        else:
            disk=table(f'MO-PRED-03E*/MO*{y}_PREDICTIONS.csv').set_index('originUtc')
            disk=disk.rename(columns={f'M{i}_prediction':f'M{i}' for i in range(5)})
        disk.index=pd.to_datetime(disk.index,utc=True)
        assert set(disk.index)==set(ix)
        info['maxForecastResidual']=max(float(np.max(abs(disk.loc[ix,f'M{i}'].to_numpy()-preds[i]))) for i in range(5))
    if label in ('test','2023','2024'):
        ixpath=one('MO-PRED-03D-R1*/*INDICES.npy' if y==2022 else f'MO-PRED-03E*/*INDICES_{y}.npy')
        idx=np.load(ixpath,mmap_mode='r')
        a=(target-preds[1])**2;b=(target-preds[4])**2
        ds=[];dr=[]
        for chunk in np.array_split(idx,40):
            v=a[chunk].mean(axis=1);w=b[chunk].mean(axis=1)
            ds.extend(v-w);dr.extend(np.sqrt(v)-np.sqrt(w))
        info.update(deltaMSE=float((a-b).mean()),ciMSE=np.quantile(ds,[.025,.975]).tolist(),deltaRMSE=float(np.sqrt(a.mean())-np.sqrt(b.mean())),ciRMSE=np.quantile(dr,[.025,.975]).tolist(),replicates=len(idx))
    answer['populations'][label]=info
answer['coefficients']={str(i):v.tolist() for i,v in coefs.items()}
print(json.dumps(answer,indent=2))

