"""Fresh-process, read-only probe of the working tree's real phase service."""
import os,sys,json,tempfile
from pathlib import Path
from datetime import datetime,timezone
root=Path('D:/gann_r2b_sec_integration')
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'gann-astro-desk/backend'))
import avg_all_currency_phase as service
import swisseph as swe
t=int(datetime(2025,5,31,17,tzinfo=timezone.utc).timestamp())
with tempfile.TemporaryDirectory() as empty:
    os.environ['GANN_ASTRO_EPHEMERIS_PATH']=empty if '--fallback' in sys.argv else 'D:/Trading_Algo/Desktop_Trading_Algo_root_legacy_20260530/sweph'
    res=service.build_avg_all_currency_phase({'symbol':'USDJPY','timeframe':'H1','timestamps':[t]})
    other=service.build_avg_all_currency_phase({'symbol':'USDJPY','timeframe':'H4','timestamps':[t]})
    assert res['phaseSamples']==other['phaseSamples']
    values,ret=swe.calc_ut(swe.julday(2025,5,31,17),swe.SUN,swe.FLG_SIDEREAL|swe.FLG_SPEED|swe.FLG_SWIEPH)
    s=res['phaseSamples'][0]
    print(json.dumps(dict(mode='fallback requested via empty directory' if '--fallback' in sys.argv else 'Swiss path',contract=res['astronomyContract'],top_level_fields=list(res),sample=s,diagnostic_sun_return_flags=ret,same_H1_H4=True),indent=2))

