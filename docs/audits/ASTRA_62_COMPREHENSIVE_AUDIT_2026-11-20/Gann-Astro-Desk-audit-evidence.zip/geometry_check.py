"""Read frozen hourly features and compare against independent Swiss-file calculations."""
import csv,cmath,math,json,random
from datetime import datetime,timedelta
from pathlib import Path
import swisseph as swe
r=Path('D:/GannFinancialAstro/research_outputs')
swe.set_ephe_path('D:/Trading_Algo/Desktop_Trading_Algo_root_legacy_20260530/sweph')
swe.set_sid_mode(swe.SIDM_RAMAN)
flags=swe.FLG_SIDEREAL|swe.FLG_SWIEPH|swe.FLG_SPEED
def lons(d,n):
    jd=swe.julday(d.year,d.month,d.day,d.hour+d.minute/60+d.second/3600)
    ans=[]
    for body in range(n):
        v,ret=swe.calc_ut(jd,body,flags)
        assert ret&swe.FLG_SWIEPH
        ans.append(math.radians(v[0]))
    return ans
def vec(angles,k=1):return sum(cmath.exp(1j*k*a) for a in angles)/len(angles)
def proj(a,b):return (vec(a)*vec(b).conjugate()).real
def direct(a,b):return math.fsum(math.cos(x-y) for x in a for y in b)/(len(a)*len(b))
times=[datetime(1776,7,4,16,56,2),datetime(1889,2,10,15)]
u,j=[lons(t,7) for t in times]
out={'natal_vectors':[[vec(s).real,vec(s).imag] for s in (u,j)],'max_pair_amplitude':abs(vec(u)-vec(j)),'projection_axes_det':vec(u).real*vec(j).imag-vec(j).real*vec(u).imag,'natal_one_hour_change_bound':{str(t):abs(vec(lons(t+timedelta(hours=1),7))-vec(lons(t,7))) for t in times}}
for y in (2022,2023,2024):
    file=next(r.glob(f'*/MO*{y}_ASTRONOMICAL_FEATURES.csv'))
    worst=0;count=0
    with file.open() as f:
        for row in csv.DictReader(f):
            d=datetime.fromisoformat(row['timestampUtc']); a=lons(d,7);v=vec(a)
            predicted=[v.real,v.imag,direct(a,u),direct(a,j),direct(a,u)-direct(a,j)]
            recorded=[float(row[c]) for c in ('T_x','T_y','W_USD','W_JPY','R')]
            worst=max(worst,*[abs(p-q) for p,q in zip(predicted,recorded)]); count+=1
    out[str(y)]={'n':count,'max_abs_error':worst,'file':file.name}
a=lons(datetime(2025,5,31,17),10)
out['ten_body_example']={'usd':direct(a,u),'jpy':direct(a,j),'difference':direct(a,u)-direct(a,j),'R1':abs(vec(a)),'R2':abs(vec(a,2))}
rng=random.Random(61119);err=0
for n in (7,10):
    for _ in range(512):
        a=[rng.uniform(-20,20) for _ in range(n)];b=[rng.uniform(-20,20) for _ in range(7)]
        err=max(err,abs(direct(a,b)-proj(a,b)))
        assert abs(proj(a,b))<=abs(vec(a))*abs(vec(b))+1e-14
        assert abs(proj(a[::-1],b)-proj(a,b))<1e-14
        assert abs(proj([x+.75 for x in a],[x+.75 for x in b])-proj(a,b))<1e-14
assert abs(vec([0,math.pi]))<1e-14 and abs(abs(vec([0,math.pi],2))-1)<1e-14
assert abs(vec([0,math.pi/2,math.pi,3*math.pi/2],2))<1e-14
out['max_random_factorization_residual']=err
print(json.dumps(out,indent=2))

