"""Compare an independent implementation against the transcribed p.24 matrix."""
import json, csv
from fractions import Fraction as F
from bisect import bisect_right
from pathlib import Path
planets=['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn']
positions=[(180,53,55),(311,17,19),(229,30,34),(181,31,34),(84,0,49),(171,9,56),(124,22,41)]
lons=[F(d)+F(m,60)+F(s,3600) for d,m,s in positions]
lords=[2,5,3,1,0,3,5,2,4,6,6,4]
friends=[{1,2,4},{0,3},{0,1,4},{0,5},{0,1,2},{3,6},{3,5}]
enemies=[{5,6},set(),{3},{1},{3,5},{0,1},{0,1,2}]
source=Path('D:/GannFinancialAstro/research_outputs/SHADBALA_R1_5_R1_20261119/SAPTAVARGA_49_CELL_MATRIX.csv')
oracle={(r['planet'],r['varga']):float(r['printed_virupas']) for r in csv.DictReader(source.open())}
vargas=['D1','D2','D3','D7','D9','D12','D30']
def divisions(x):
    s=int(x//30);a=x%30;odd=s%2==0
    d30=([0,10,8,2,6] if odd else [1,5,11,9,7])[bisect_right([5,10,18,25] if odd else [5,12,20,25],a)]
    return [s,4 if (a<15)==odd else 3,(s+4*(a//10))%12,(s+(0 if odd else 6)+a*7//30)%12,(x*9//30)%12,(s+a*12//30)%12,d30]
def compare(alt):
    pos=[divisions(x) for x in lons]
    if alt:pos[4][-1]=5
    scores={}
    for policy in ['A','B']:
        rows=[]
        for i,planet in enumerate(pos):
            row=[]
            for k,sign in enumerate(planet):
                lord=lords[sign]; base=0 if policy=='A' else k
                rel=(pos[lord][base]-planet[base])%12
                natural=int(lord in friends[i])-int(lord in enemies[i])
                grade=natural+(1 if rel in [1,2,3,9,10,11] else -1)
                row.append(30 if i==lord else [1.875,3.75,7.5,15,22.5][grade+2])
            rows.append(row)
        scores[policy]={'matches':sum(x==oracle[p,v] for p,row in zip(planets,rows) for v,x in zip(vargas,row)),'scores':rows}
    return scores
fall=[190,213,118,345,275,177,20]
uccha=[min(abs(x-a),360-abs(x-a))/3 for x,a in zip(lons,fall)]
print(json.dumps({'relationship':compare(False),'alternate_jupiter_D30':{p:v['matches'] for p,v in compare(True).items()},'page24_sums':{p:sum(oracle[p,v] for v in vargas) for p in planets},'exact_uccha':{p:str(x) for p,x in zip(planets,uccha)}},indent=2))

