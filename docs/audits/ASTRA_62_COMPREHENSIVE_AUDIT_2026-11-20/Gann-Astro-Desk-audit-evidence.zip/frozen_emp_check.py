"""Check the historically frozen result artifact and adjustment math only."""
import hashlib,json,subprocess
rev='ef691e75151bc2c296f98a84383e8e30adf6bb9e'
blob=subprocess.check_output(['git','-C','D:/PycharmProjects','show',rev+':status/research/mo_r4a_candidate_c_emp2_market_association_result_v1.json'])
d=json.loads(blob);out={'commit':rev,'git_blob_content_sha256':hashlib.sha256(blob).hexdigest()}
for name in ('primaryFamily','secondaryFamily'):
    fam=d[name];p=sorted(fam['rawPValues'].items(),key=lambda x:x[1])
    m=len(p);values={}
    if name=='primaryFamily':
        v=0
        for i,(key,raw) in enumerate(p):
            v=max(v,min(1,(m-i)*raw));values[key]=v
    else:
        v=1
        for i in reversed(range(m)):
            key,raw=p[i];v=min(v,m*raw/(i+1));values[key]=v
    out[name]={'n':m,'raw_range':[p[0][1],p[-1][1]],'recalculated_adjusted_values':sorted(set(values.values())),'max_disagreement':max(abs(v-fam['adjustedPValues'][k]) for k,v in values.items())}
out['retention_by_test']=[{'side':x['sideIdentity'],'test':x['testId'].split('::')[-2:],'source_eligible':x['sourceEligibleEventCount'],'market_eligible':x['retainedMarketEligibleEventCount']} for x in d['testLedger']]
print(json.dumps(out,indent=2))

