"""Measure the backend function wall time and peak response sizes. No UI timing inferred."""
import sys,time,json
from datetime import datetime,timezone
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'D:/gann_r2b_sec_integration/gann-astro-desk/backend')
from avg_all_currency_phase import build_avg_all_currency_phase
t=int(datetime(2025,5,31,17,tzinfo=timezone.utc).timestamp())
rows=[]
for n in (1,168,336,720,1200,336):
    payload=dict(symbol='USDJPY',timeframe='H1',timestamps=[t+3600*i for i in range(n)])
    start=time.perf_counter()
    result=build_avg_all_currency_phase(payload)
    elapsed=time.perf_counter()-start
    rows.append(dict(n=n,seconds=elapsed,compact_utf8_json_bytes=len(json.dumps(result,separators=(',',':')).encode()),valid=sum(s['status']=='VALID' for s in result['phaseSamples'])))
out={'runs':rows}
try:
    build_avg_all_currency_phase(dict(symbol='USDJPY',timeframe='H1',timestamps=[t+3600*i for i in range(1201)]))
except ValueError as e:out['n1201']=str(e)
print(json.dumps(out,indent=2))

